#! /bin/sh

killall gb28181device